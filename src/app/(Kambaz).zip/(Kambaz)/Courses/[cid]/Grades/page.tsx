export default function Grades() {
  return (
    <div>
      <h2>Grades</h2>
    </div>
);}
