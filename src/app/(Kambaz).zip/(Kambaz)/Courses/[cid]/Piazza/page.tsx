export default function Piazza() {
  return (
    <div>
      <h2>Piazza</h2>
    </div>
);}
