export default function Quizzes() {
  return (
    <div>
      <h2>Quizzes</h2>
    </div>
);}
