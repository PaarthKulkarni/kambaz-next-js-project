export default function Zoom() {
  return (
    <div>
      <h2>Zoom</h2>
    </div>
);}
