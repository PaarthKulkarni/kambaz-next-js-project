export default function Inbox() {
  return (
    <div>
      <h2>Inbo</h2>
    </div>
);}
